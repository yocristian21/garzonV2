<?php

define('URL', 'http://localhost/garzon_2/');

define('HOST', 'localhost');
define('DB', 'garcon');
define('USER', 'root');
define('PASSWORD', "abc12345");
define('CHARSET', 'utf8mb4');

?>