<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div id="main">
        <a href="<?php echo constant('URL'); ?>admin/adm_product"><input type="button" value="Administrar Productos"/></a>
        <br>
        <br>
        Administrar Pedidos
        <br>
        <br>
        <a href="<?php echo constant('URL'); ?>login/finalizar"><input type="button" value="Cerrar Sesion"/></a>
    </div>
</body>
</html>