<div id="static_menu">
    <hr>
    <br>
    <br>
        <center>
            <a href="<?php echo constant('URL'); ?>carta"><input type="button" value="Ver Carta"/></a>
            <a href="<?php echo constant('URL'); ?>pedidos"><input type="button" value="Ver Pedidos"/></a>
            <a href=""><input type="button" value="Llamar Mozo"/></a>
            <a href=""><input type="button" value="Ayuda"/></a>
        </center>
    <br>
    <br>
</div>