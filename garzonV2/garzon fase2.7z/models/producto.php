<?php

class Producto{

    public $id_producto;
    public $nombre;
    public $descripcion;
    public $precio;
    public $foto;
    public $stock;
    public $categoria;
}

?>